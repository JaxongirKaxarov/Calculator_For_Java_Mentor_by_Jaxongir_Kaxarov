package exercise_n1_kaxarov_jaxongir_calculator;

public class Main {
    public static void main(String[] args) 
    {
        while (true) {
            try 
            { 

                System.out.println("Введите выражение:");
 
                DataReader reader = new DataReader();
                reader.read();    
                
                int result = Calculator.calculate(reader.getNumber1(), reader.getNumber2(), reader.getOperation());
 
                if(reader.enteredRomanNumbers())
                {
                    RomanNumeral N = new RomanNumeral(result);
                    System.out.println(N.toString());
                }
                else
                {
                    System.out.println(result);
                }

            } 
            catch (RuntimeException e) 
            {
                System.err.println("Вы ввели неправилное число. "+e.getMessage());
                break;
            }

        }
    }
}