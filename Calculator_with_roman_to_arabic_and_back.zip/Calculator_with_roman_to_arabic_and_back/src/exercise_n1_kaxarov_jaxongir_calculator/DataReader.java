package exercise_n1_kaxarov_jaxongir_calculator;

import exercise_n1_kaxarov_jaxongir_calculator.RomanNumeral;
import java.util.Scanner;

public class DataReader {
 
    int number1;
    int number2;
    private char operation;
    private boolean enteredRomanNumbers;

    public void read() 
    {
     
        String[] arabic1 = {"8", "7", "6", "4", "9", "3", "2", "5", "10", "1"};
        String[] roman = { "VIII", "VII", "VI", "IV", "IX", "III", "II", "V", "X", "I"};
        
        Scanner scanner = new Scanner(System.in);
        
        String a = scanner.nextLine();
        a = a.toUpperCase();
        String b = a.replaceAll(" ","");
        String text1 = b.replaceAll("=","");
        
        // проверяем, входит ли строка blocks[0] в массив строк массива "roman"
        boolean cheker;
        for (int i = 0; i < roman.length; i++) {
            String[] blocks = text1.split("[+-/*]");
            if (blocks[0].equals(roman[i]) || blocks[1].equals(roman[i])) {
                enteredRomanNumbers = true;
            }
            else if(blocks[0].equals(arabic1[i]) || blocks[1].equals(roman[i])||blocks[0].equals(roman[i]) || blocks[1].equals(arabic1[i])){
                throw new IllegalArgumentException();
            }
        }

        String text2 = text1.replaceAll("VIIi","8"); 
        String text3 = text2.replaceAll("VII","7");
        String text4 = text3.replaceAll("VI","6");
        String text5 = text4.replaceAll("IV","4");
        String text6 = text5.replaceAll("V","5");
        String text7 = text6.replaceAll("IX","9");
        String text8 = text7.replaceAll("X","10");
        String text9 = text8.replaceAll("III","3");
        String text0 = text9.replaceAll("II","2");
        String text = text0.replaceAll("I","1");   
        String[] blocks = text.split("[+-/*]");
        


        try
        {
            number1 = Integer.parseInt(blocks[0]);
            number2 = Integer.parseInt(blocks[1]);
            operation = text.charAt(blocks[0].length());
        }
        catch (RuntimeException e) {
            throw new IllegalArgumentException("Неверный формат данных "
                + "Завершение программы.\n\""+e.getMessage()+"\"");
        }
         
        if ((number1 > 10 || number1 < 0 || number1 == 0) || (number2 > 10 || number2 < 0 || number2 == 0)) {
            throw new IllegalArgumentException();
        }

    }
 
    public int getNumber1() {
        return number1;
    }
 
    public int getNumber2() {
        return number2;
    }
 
    public char getOperation() {
        return operation;
    }
 
    public boolean enteredRomanNumbers() {
        return enteredRomanNumbers;
    }
}
 

