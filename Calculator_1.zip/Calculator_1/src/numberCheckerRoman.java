
public class numberCheckerRoman {
    static boolean bruteForce(String text){
        String[] roman = {"IX","X","VIII","VII","VI","IV","V","III","II","I"};
        for (String keyword : roman){
            if (text.contains(keyword)){
                return true;
            }
        }
        return false;
    }
}
